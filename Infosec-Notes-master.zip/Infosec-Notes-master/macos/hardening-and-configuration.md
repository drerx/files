# Hardening & Configuration

{% hint style="success" %}
Hack Responsibly.

Always ensure you have **explicit** permission to access any computer system **before** using any of the techniques contained in these documents. You accept full responsibility for your actions by applying any knowledge gained here.‌
{% endhint %}

  
Nothing here yet...please feel free to contribute 5KFB6 at [https://www.github.com/zweilosec](https://github.com/zweilosec)​

## Resources

* [https://github.com/ernw/hardening/blob/master/operating\_system/osx/10.14/ERNW\_Hardening\_OS\_X\_Mojave.md](https://github.com/ernw/hardening/blob/master/operating_system/osx/10.14/ERNW_Hardening_OS_X_Mojave.md)
* 
