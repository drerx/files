# Socat

Pivoting using Socat
