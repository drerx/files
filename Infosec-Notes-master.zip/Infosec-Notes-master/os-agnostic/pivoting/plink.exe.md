# Plink.exe

Pivoting using Plink.exe
