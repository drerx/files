---
description: >-
  A collection of useful programs and configurations for getting your home box
  set up for pre-engagement use. I think I want to rename this page to something
  else...can't think of a good title right now
---

# Hardening & Setup

## Hardening the OS

### Disable unused services

Disable WinRM, RDP, etc if not used

### Reduce Privacy Disclosures

disable location, telemetry, etc

## Recommended Programs

{% embed url="https://ninite.com" %}

notepad++

Visual Studio Code

Tor Browser - based on Firefox.  Be careful of settings and extensions used as these can break the protection provided by the VPN.  

