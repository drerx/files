# python-pearls
A collection of python scripts for making life easier.  Contains automation scripts for many things including exploit POCs and other userful red- and blue-team tools.


* CVE-2019-17240_bludit-3.9.2_pwd-bruteforce_multi.py: A tool for brute-forcing the Admin portal login of Bludit CMS 3.9.2 or earlier.
* CVE-2018-1000854_exploit.py: Tool for remote code execution in exposed vulnerable fields for servers using Esigate 5.2 or earlier.
